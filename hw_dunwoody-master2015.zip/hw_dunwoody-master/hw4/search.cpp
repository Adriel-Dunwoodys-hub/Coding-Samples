#include <iostream>
#include <sstream>
#include <fstream>
#include <set>
#include <vector>
#include <string>
#include <map>

#include "webpage.h"
#include "searcheng.h"
#include "pagepaser.h"
#include "util.h"
#include "myset.h"

using namespace std;

void display_results(set<WebPage*>& results);

int main(int argc, char* argv[])
{
  if(argc < 2){
    cerr << "usage: ./search index_file...Please provide an index file" << endl;
    return 1;
  }

  /****************   Add code to ***************************/
  /* Initialize your search engine and parse all the pages */
  SearchEng search;
  string index_file;
  string file_name;
  string answer;
  WebPage *parser = new WebPage;
  MySetString *blah = new MySetString;
  bool loop = false;
  
  while(!loop)
  {
	  cout << "Are you going to use an index file or a single file?\n";
	  cout << "Type 'y' for yes and for a single file type 'n'.\n";
	  cin >> answer;
	  if(convToLower(answer) == "y")
	  {
		  loop = true;
		  cout << "Please type in the index file name.\n";
		  cin >> index_file;
		  search.add_parse_from_index_file(index_file,parser);
	  }
	  else if(convToLower(answer) == "n")
	  {
		  loop = true;
		  search.add_parse_page(index_file,parser);
	  }
	  else
	  {
		  cout << "Error please type 'y' or 'n'";
	  }
  }



  string myline;
  bool done = false;
  while( !done )
  {
    cout << "\n++++++++++++++++++++" << endl;
    cout << "Enter search terms: " << endl;
	cout << "Enter in '.' to end the program." << endl;
    getline(cin, myline);
    cout << "++++++++++++++++++++\n" << endl;

    /* Add your code here and feel free to modify    */
    /*  what is above but don't change the display.  */
    /* Call display_results() with the set of pages  */
    /*  that match the search. It will display the   */
    /*  matching results to the screen for you.      */
	istringstream iss(myline);
    string word;
	iss >> word;
	if(convToLower(word) == "and")
		{
			while(iss >> word) 
			{
				//use intersection function
				//blah->set_intersection(parser);
				//display what set_intersection found
				//display_results();
			}
		}
	else if(convToLower(word) == "or")
		{
			while(iss >> word)
			{
				//use union function
				//display what set_intersection found
				//display_results();
			}
		}
    


    }
  return 0;
}

void display_results(set<WebPage*>& results)
{
  int hits = results.size();
  cout << hits << " hits." << endl;
  cout << "=====" << endl;
  int i=0;
  for(set<WebPage*>::iterator it = results.begin();
      it != results.end();
      ++it)
    {
      cout << (*it)->filename() << endl;
      cout << "+---+" << endl;
      cout << (**it) << "\n" << endl;
      i++;
    }
  
}

void SearchEng::add_parse_from_index_file(std::string index_file, 
				 PageParser* parser)
{
	MySetString words;
	MySetString links;
	ofstream file;
	file.open(index_file);
	parser->parse(index_file,words,links);
	set<string>::iterator iter;
	int ii = 0;
	for(iter=words.begin(); iter!=words.end();++iter)
	{
		stored<*iter,Webpage>;
		ii+=1;
	}
}

 void SearchEng::add_parse_page(std::string filename,PageParser* parser)
{
	MySetString words;
	MySetString links;
	ofstream file;
	file.open(filename);
	parser->parse(filename,words,links);
	set<string>::iterator iter;
	int ii = 0;
	for(iter=words.begin(); iter!=words.end();++iter)
	{
		stored<*iter,Webpage>;
		ii+=1;
	}
}
