#include "myset.h"
#include "webpage.h"
#include "pagepaser.h"
#include <set>
#include <stdlib.h>
#include <fstream>
#include <string>
#include <locale>
#include <stdio.h>
#include <ctype.h>
#include <set>
#include <queue>

using namespace std;

void PageParser::parse(std::string filename,
		     MySetString& allWords,
		     MySetString& allLinks)
{
	std::queue<char> list;
	ifstream file;
	char c;
	char a;
	string check;
	string added;//string to add chars to
	int i;
	bool isLink = false;

	i = 0;
	while(i < filename.size())
	{
		c = check[i];
		//if it is a digit or alphabetic char
		if(isdigit(c) || isalpha(c))
		{
			list.push(c);//put char into queue
				
		}
		else if(c == '(')
		{
			isLink = true;
		}
		else//then it is a special character
		{
			if(isLink == true)//if it is true
			{
				if(c == '.')
				{
					list.push(c);//allow the period to go in queue
				}
				else//making sure popping is executed after not finding a period
				{
					while(!list.empty())
				{
					a = list.front();
					list.pop();
					added+=a;//add the character to the end of the string added
				}
				//store the word into either set if not empty
				if(added!="");//make sure it is not empty and dont add it to stack
				{
					if(isLink)
					{
						allLinks.insert(added);
						isLink = false;
					}
					else
					{
						allWords.insert(added);
					}
					added = "";//make added an empty string again
				}
				}
			}
			else
			{
				//keep popping and adding to a string until queue is empty
				while(!list.empty())
				{
					a = list.front();
					list.pop();
					added+=a;//add the character to the end of the string added
				}
				//store the word into either set if not empty
				if(added!="");//make sure it is not empty and dont add it to stack
				{
					if(isLink)
					{
						allLinks.insert(added);
						isLink = false;
					}
					else
					{
						allWords.insert(added);
					}
					added = "";//make added an empty string again
				}
					
			}
		}
		i++;
	}//end of getLine while loop
}
