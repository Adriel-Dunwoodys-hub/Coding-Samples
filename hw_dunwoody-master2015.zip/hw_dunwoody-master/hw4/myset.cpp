// myset.cpp : Defines the entry point for the console application.
//

#include "myset.h"
#include "webpage.h"

MySetString::MySetString() : std::set<std::string>() {}

MySetString MySetString::set_intersection(const MySetString& other) {

}

MySetString MySetString::set_union(const MySetString& other) {

}

MySetWebPage::MySetWebPage() : std::set<WebPage*>() {}

MySetWebPage MySetWebPage::set_intersection(const MySetWebPage& other) {

}

MySetWebPage MySetWebPage::set_union(const MySetWebPage& other) {

}
