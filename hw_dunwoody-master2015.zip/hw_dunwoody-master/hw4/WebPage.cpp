#include <iostream>
#include <stdlib.h>
#include <string>
#include <locale>
#include <stdio.h>
#include <ctype.h>
#include <set>
#include <queue>
#include "myset.h"

using namespace std;

void all_words(const MySetString& words)
{
	//create the 2 sets
	std::set<string> allWords;
	std::set<string> allLinks;
	std::queue<char> list;
	char c;
	char a;
	string check;
	string added;//string to add chars to
	int i;
	bool isLink = false;

	//Parsing method goes here
	//read in the 2nd file
	i = 0;
	check = "Hello world [hi](data2.txt). Table chair desK, t-bone steak.";
	while(i < check.size())
	{
		c = check[i];
		//if it is a digit or alphabetic char
		if(isLink == false && (isdigit(c) || isalpha(c)))
		{
			list.push(c);//put char into queue
				
		}
		else if(c == '(')
		{
			isLink = true;
		}
		else if(c == ')')
		{
			isLink = false;
		}
		else//then it is a special character
		{
			if(isLink == true)//if it is true
			{
				break;
			}
			else
			{
				//keep popping and adding to a string until queue is empty
				while(!list.empty())
				{
					a = list.front();
					list.pop();
					added+=a;//add the character to the end of the string added
				}
				//store the word into either set if not empty
				if(added!="");//make sure it is not empty and dont add it to stack
				{
					if(isLink==false)

					{
						allWords.insert(added);
					}
					added = "";//make added an empty string again
				}
				
			}
		}
		i++;
	}
}
