#include "myset.h"
#include <set>


MySetString::MySetString()
{
	std::set<std::string>;
}

MySetString MySetString::set_intersection(const MySetString& other) 
{
	MySetString temp;
	return temp;
}

MySetString MySetString::set_union(const MySetString& other) 
{
	MySetString temp;
	return temp;
}
