#ifndef UTIL_H
#define UTIL_H

#include <string>

std::string convToLower(std::string src);

#endif
