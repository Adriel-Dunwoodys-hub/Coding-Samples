This folder contains the hellowworld.cpp file.
